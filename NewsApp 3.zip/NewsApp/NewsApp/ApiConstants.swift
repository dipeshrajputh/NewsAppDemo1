//
//  ApiConstants.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//

import Foundation

struct ApiConstants {
    static let baseUrl = "https://newsapi.org/v2/top-headlines?country=us&apiKey=7bcec68af39849a7bfb12ea9406c85ac"
}
