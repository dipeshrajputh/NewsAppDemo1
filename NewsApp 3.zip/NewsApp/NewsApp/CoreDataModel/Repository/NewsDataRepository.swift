
import Foundation
import CoreData

protocol EmployeeRepository : BaseRepository {
 
    func update(news: NewsArr) -> Bool
    func delete() -> Bool
    
}

 

struct NewsDataRepository : EmployeeRepository {
     
    typealias T = NewsArr
    
    func getAll() -> [NewsArr]? {
     
        let result = PersistentStorage.shared.fetchManagedObject(managedObject: NewsEntity.self)
        var employees : [NewsArr] = []
        result?.forEach({ (cdEmployee) in
            employees.append(cdEmployee.convertToNews())
        })
        return employees
    }
    
    func update(news : NewsArr) -> Bool {
        return false
    }
    
    func delete() -> Bool {
        let fetchRequest = NSFetchRequest<NewsEntity>(entityName: EModel.NewsEntity.rawValue)
        fetchRequest.returnsObjectsAsFaults = false
        do {
            let results = try PersistentStorage.shared.context.fetch(fetchRequest)
            for object in results {
                PersistentStorage.shared.context.delete(object)
                PersistentStorage.shared.saveContext()
            }
        } catch let error {
            print("Detele all data in \(EModel.NewsEntity.rawValue) error :", error)
        }
        return true
    }
    
    
    
    func create(record: NewsArr) {
        
        let cdNews                  = NewsEntity(context: PersistentStorage.shared.context)
        
        cdNews.url = record.url
        cdNews.urlToImage = record.urlToImage
        cdNews.title = record.title
        cdNews.author = record.author
        cdNews.content = record.content
        cdNews.details = record.description
         
        PersistentStorage.shared.saveContext()
    }
    
    
    /*
   

    func get() -> UserModel? {

        let result = getCDEmployee()
        guard result != nil else {return nil}
        return result?.convertToEmployee()
        
    }
  
    func update(employee: UserModel) -> Bool {

        let cdEmployee = getCDEmployee()
         
        guard cdEmployee != nil else {
           // print("user vehicle assined faild- - - - - - ->Final Data")
            return false
            
        }

        if employee.userName != "" && employee.userName != nil {
            cdEmployee?.userName = employee.userName
        }
        
        PersistentStorage.shared.saveContext()
        return true
    }

    func delete() -> Bool {

        let cdEmployee = getCDEmployee()
        guard cdEmployee != nil else {return false}
        PersistentStorage.shared.context.delete(cdEmployee!)
        PersistentStorage.shared.saveContext()
        return true
    }

    func deleteAllData() {
        let fetchRequest = NSFetchRequest<CDUser>(entityName: EModel.entityName_name.rawValue)
        fetchRequest.returnsObjectsAsFaults = false
        do {
            let results = try PersistentStorage.shared.context.fetch(fetchRequest)
            for object in results {
                PersistentStorage.shared.context.delete(object)
                PersistentStorage.shared.saveContext()
            }
        } catch let error {
            print("Detele all data in \(EModel.entityName_name.rawValue) error :", error)
        }
    }
    
    private func getCDEmployee() -> CDUser? {
        let fetchRequest = NSFetchRequest<CDUser>(entityName: EModel.entityName_name.rawValue)
        /*
        if let date = date {
            let predicate = NSPredicate(format: "date==%@", date as CVarArg)
            fetchRequest.predicate = predicate
            
        }*/
        
        fetchRequest.sortDescriptors   = [NSSortDescriptor(key: "date", ascending: false)]
        fetchRequest.fetchLimit        = 1
        
        do {
            let result = try PersistentStorage.shared.context.fetch(fetchRequest).first
            guard result != nil else {return nil}
            return result

        } catch let error {
            debugPrint(error)
        }

        return nil
    }*/
}
