//
//  NewsEntity+CoreDataClass.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//
//

import Foundation
import CoreData

@objc(NewsEntity)
public class NewsEntity: NSManagedObject {

}
