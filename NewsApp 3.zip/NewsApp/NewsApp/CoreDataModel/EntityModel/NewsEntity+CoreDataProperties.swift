//
//  NewsEntity+CoreDataProperties.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//
//

import Foundation
import CoreData


extension NewsEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<NewsEntity> {
        return NSFetchRequest<NewsEntity>(entityName: "NewsEntity")
    }

    @NSManaged public var author: String?
    @NSManaged public var title: String?
    @NSManaged public var details: String?
    @NSManaged public var urlToImage: String?
    @NSManaged public var content: String?
    @NSManaged public var url: String?
    
    func convertToNews() -> NewsArr {
        return NewsArr(author: author,title: title,description:details ,urlToImage: urlToImage, content: content, url:url)
    }

}

extension NewsEntity : Identifiable {

}
