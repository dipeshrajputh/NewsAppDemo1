//
//  BaseRepository.swift
//  Blue-ELD
//
//  Created by Dipesh Sisodiya on 16/07/22.
//

import Foundation

protocol BaseRepository {
    
    associatedtype T
    
    func create(record: T)
    func getAll() -> [T]?
    
    
}
