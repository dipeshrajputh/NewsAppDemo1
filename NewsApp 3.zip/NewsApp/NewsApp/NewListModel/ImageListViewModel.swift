//
//  ImageListViewModel.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//
 

import Foundation

class ImageListViewModel  {
     
    var  dataBaseObj : Database
    init(dataBaseObj: Database) {
        self.dataBaseObj = dataBaseObj
    }
    
    func fetchImages(completion:@escaping (NewsModel) -> Void) {
        
        
        
        URLSession.shared.dataTask(with: URL(string: ApiConstants.baseUrl)!) { data, response, error in
            
            let httpResponse = response as? HTTPURLResponse
            
            if httpResponse?.statusCode == 200 {
                if let data = data {
                    do {
                        let imageResponse = try JSONDecoder().decode(NewsModel.self, from: data)
                        DispatchQueue.main.async {
                            
                            
                            self.dataBaseObj.daveData(arrN: imageResponse.newsArr ?? [])
                        }
                        
                        
                        completion(imageResponse)
                    } catch {
                        print("Error decoding JSON: \(error)")
                    }
                }
            }
            
            
            if((error) == nil) {
                
            }
            
        }.resume()
    }
}


protocol Database {
    
    func daveData(arrN : [NewsArr])
}



class SaveCoreData : Database{
    var newRepositoryObj =  NewsDataRepository()
     
    func daveData(arrN : [NewsArr]) {
        guard arrN.isEmpty == false  else {return}
        
        if checkWiFi() == true {
           _ = newRepositoryObj.delete()
        }
         
        arrN.forEach { val in
            newRepositoryObj.create(record: val)
        }
    }
    
    func getAllNews()->[NewsArr]{
        return  newRepositoryObj.getAll() ?? []
    }
    
    
}
