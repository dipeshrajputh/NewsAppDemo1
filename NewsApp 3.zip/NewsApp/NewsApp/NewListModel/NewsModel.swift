//
//  ImageModel.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//

import Foundation


struct NewsModel: Codable {
    
    let status : String
    var newsArr : [NewsArr]?
    
    enum CodingKeys: String, CodingKey {
        
        case status = "status"
        case newsArr = "articles"
    }
    
}

struct NewsArr: Codable {
    var author      : String?
    var title       : String?
    var description : String?
    var urlToImage  : String?
    var content     : String?
    var url     : String?
    
    enum CodingKeys: String, CodingKey {
          
        
        case url = "url"
        case author = "author"
        case title = "title"
        case description = "description"
        case urlToImage = "urlToImage"
        case content = "content"
        
        
    }
    
    // Add any other properties you need for the image
}
