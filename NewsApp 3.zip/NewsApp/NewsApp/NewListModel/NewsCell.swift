//
//  NewsCell.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//

import UIKit

class NewsCell: UITableViewCell {
    let imageViewModel = ImageViewModel()
    @IBOutlet weak var imgV : UIImageView!
    @IBOutlet weak var titleL : UILabel!
    var imageUrl : String = "" {
        didSet {
            if let imageUrl = URL(string: imageUrl)  {
                imageViewModel.getImage(withURL: imageUrl) { [weak self] image in
                    if let image = image {
                        self?.imgV.image = image
                    } else {
                        // Handle image loading error
                    }
                }
            }
        }
    }
    
}
