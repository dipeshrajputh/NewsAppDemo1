//
//  ViewController.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//

import UIKit

class ViewController: UIViewController {

     
    var newsModel  : [NewsArr]?
    @IBOutlet weak var tableView : UITableView!
    var coreDataObj = SaveCoreData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        if checkWiFi() == false {
            self.newsModel = self.coreDataObj.getAllNews()
            self.tableView.reloadData()
            return
        }
        
        let viewModel = ImageListViewModel(dataBaseObj: coreDataObj)
        viewModel.fetchImages(completion: { result in 
            DispatchQueue.main.async {
                self.newsModel = self.coreDataObj.getAllNews()
                self.tableView.reloadData()
            }
        })
        // Do any additional setup after loading the view.
    }


}

extension ViewController: UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsModel?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewsCell", for: indexPath) as! NewsCell
        if let dic = newsModel?[indexPath.row] {
            cell.titleL.text = dic.title
            cell.imageUrl = dic.urlToImage ?? ""
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let dic = newsModel?[indexPath.row] {
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailsVc = storyBoard.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
            detailsVc.urlStr = dic.url
            self.navigationController?.pushViewController(detailsVc, animated: true )
        }
    }
}
