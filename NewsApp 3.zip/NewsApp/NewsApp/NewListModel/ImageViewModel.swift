//
//  ImageViewModel.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//

import Foundation
import UIKit

class ImageViewModel {
    private var imageCache = NSCache<NSString, UIImage>()

    func getImage(withURL url: URL, completion: @escaping (UIImage?) -> Void) {
        if let cachedImage = imageCache.object(forKey: url.absoluteString as NSString) {
            completion(cachedImage)
        } else {
            downloadImage(withURL: url, completion: completion)
        }
    }

    private func downloadImage(withURL url: URL, completion: @escaping (UIImage?) -> Void) {
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let data = data, let image = UIImage(data: data) {
                self.imageCache.setObject(image, forKey: url.absoluteString as NSString)
                DispatchQueue.main.async {
                    completion(image)
                }
            } else {
                DispatchQueue.main.async {
                    completion(nil)
                }
            }
        }.resume()
    }
}
