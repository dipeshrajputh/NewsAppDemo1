//
//  DetailsViewController.swift
//  NewsApp
//
//  Created by Dipesh Sisodiya on 21/10/23.
//

import UIKit
import WebKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var webView : WKWebView!
    
    var urlStr : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        if let srt = urlStr ,let link = URL(string:srt) {
            let request = URLRequest(url: link)
            webView.load(request)
            
        }
       
        // Do any additional setup after loading the view.
    }
    
 
}
